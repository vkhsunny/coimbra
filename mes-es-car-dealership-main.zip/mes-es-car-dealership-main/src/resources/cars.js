export default [
  {
    id: '',
    model: '',
    color: '',
    year: '',
  },
  {
    id: '',
    model: '',
    color: '',
    year: '',
  },
  {
    id: '',
    model: '',
    color: '',
    year: '',
  },
  {
    id: '',
    model: '',
    color: '',
    year: '',
  },
  {
    id: '',
    model: '',
    color: '',
    year: '',
  },
  {
    id: '',
    model: '',
    color: '',
    year: '',
  },
  {
    id: '',
    model: '',
    color: '',
    year: '',
  },
];
