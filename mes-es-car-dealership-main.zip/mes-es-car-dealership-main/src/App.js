import './App.css';
import AppEntryPoint from './main/AppEntryPoint';

function App() {
  return <AppEntryPoint />;
}

export default App;
