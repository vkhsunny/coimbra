const CarStatus = () => {
  return <p>CarStatus test</p>;
};

export default CarStatus;
