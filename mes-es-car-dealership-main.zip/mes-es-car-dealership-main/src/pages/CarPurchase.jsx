const CarPurchase = () => {
  return <p>CarPurchase test</p>;
};

export default CarPurchase;
