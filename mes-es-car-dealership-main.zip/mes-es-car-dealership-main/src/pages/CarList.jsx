const CarList = () => {
  return <p>Carlist test</p>;
};

export default CarList;
